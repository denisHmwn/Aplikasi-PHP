<?php include("config.php"); ?>

<html>
	<head>
		<title>Disain Bootstrap</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width", initial-scale="1" >
        <!-- 
        <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
        <script src="bootstrap/js/bootstrap.js"></script>
        <script src="bootstrap/js/jquery.js"></script>
        <link href="fontawesome/css/fontawesome.css" rel="stylesheet" />
        <link href="fontawesome/css/brands.css" rel="stylesheet" />
        <link href="fontawesome/css/solid.css" rel="stylesheet" />
        -->

        <!-- Custom fonts for this template-->
        <link rel="stylesheet" href="style_uts.css">
        
        <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
        <link
            href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
            rel="stylesheet">

        <!-- Custom styles for this template-->
        <link href="css/sb-admin-2.min.css" rel="stylesheet">
  </head>
	<body>
        <!-- navigasi -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-lg fixed-top">
            <div class="container">
              <a class="navbar-brand" href="#">Deni H.</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="text-right" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                    <a class="nav-link" href="#">Beranda</a>
                  </li><li class="nav-item">
                    <a class="nav-link" href="#layanan">Layanan</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#portofolio">Portofolio</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#tentang">Tentang</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#staff">Staff</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#kontak">Kontak Kami</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="dashboard.php"><button type="button" class="btn btn-danger btn-sm"> LOGIN </button></a>
                  </li>
                </ul>
              </div>
            </div>
        </nav>
        <!-- banner -->
        <div class="conteiner-fluid banner">
            <div class="containner text-center">
                <h4 class="display-6">Selamat Datang di Website Kami</h4>
                <h3 class="display-1">Hai.., Hallo!</h3>
                <a href="#layanan">
                    <button type="button" class="btn btn-danger btn-lg">Cek Layanan</button>
                </a>
            </div>
        </div>
        <!-- layanan -->
        <div class="container-fluid layanan pt-5 pb-5">
            <div class="container text-center">
                <h2 class="display-2" id="layanan">Layanan</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi, natus?</p>
                <div class="row pt-4">
                <?php
                    $no = 1;
                    $sql = "SELECT * FROM layanan";
                    $query = mysqli_query($db, $sql);

                    while($layanan = mysqli_fetch_array($query)){
                        echo "<div class='col-md-4'>";
                        echo "<span class='lingkaran'><i class='fas fa-fw fa-code fa-5x'></i></span>";
                        echo "<h3 class='mt-3'>".$layanan['nama']."</h3>";
                        echo "<p>".$layanan['deskripsi']."</p>";
                        echo "</div>";
                    }
                    ?>
                </div>
            </div>
        </div>
        <!-- portofolio -->
        <div class="container-fluid pt-5 pb-5 bg-light">
          <div class="container text-center">
            <h2 class="display-3" id="portofolio">Portofolio</h2>
            <p>
              Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quam, totam et cumque aperiam tenetur ullam quia alias fugit optio fugiat.
            </p>
            <div class="row pt-4 gx-4 gy-4">
              <div class="col-md-4">
                <div class="card crop-img" >
                  <img src="img/cafeshop-logo.png" class="card-img-top" width="200" height="300">
                  <div class="card-body">
                    <h5 class="card-title">Lorem, ipsum.</h5>
                    <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Animi odio atque magni quisquam cupiditate fugit accusantium aliquam iusto fugiat nostrum.</p>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="card crop-img" >
                  <img src="img/jasa-profesi-logo.png" class="card-img-top" width="200" height="300">
                  <div class="card-body">
                    <h5 class="card-title">Lorem, ipsum.</h5>
                    <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Animi odio atque magni quisquam cupiditate fugit accusantium aliquam iusto fugiat nostrum.</p>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="card crop-img" >
                  <img src="img/pendampingan-bisnis-logo.png" class="card-img-top" width="200" height="300">
                  <div class="card-body">
                    <h5 class="card-title">Lorem, ipsum.</h5>
                    <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Animi odio atque magni quisquam cupiditate fugit accusantium aliquam iusto fugiat nostrum.</p>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="card crop-img" >
                  <img src="img/mybrinmart-logo.png" class="card-img-top" width="200" height="300">
                  <div class="card-body">
                    <h5 class="card-title">Lorem, ipsum.</h5>
                    <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Animi odio atque magni quisquam cupiditate fugit accusantium aliquam iusto fugiat nostrum.</p>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="card crop-img" >
                  <img src="img/pendampingan-usaha-anggota-logo.png" class="card-img-top" width="200" height="300">
                  <div class="card-body">
                    <h5 class="card-title">Lorem, ipsum.</h5>
                    <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Animi odio atque magni quisquam cupiditate fugit accusantium aliquam iusto fugiat nostrum.</p>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="card crop-img" >
                  <img src="img/cafeshop-logo.png" class="card-img-top" width="200" height="300">
                  <div class="card-body">
                    <h5 class="card-title">Lorem, ipsum.</h5>
                    <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Animi odio atque magni quisquam cupiditate fugit accusantium aliquam iusto fugiat nostrum.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- tentang -->
        <div class="container-fluid pt-5 pb-5">
          <div class="container">
            <h2 class="display-3 text-center" id="tentang">Tentang</h2>
            <p class="text-center">Lorem ipsum dolor sit amet consectetur adipisicing elit. Possimus, consectetur.</p>
            <div class="clearfix pt-5">
              <img src="img/about_us.jpg" class="col-md-6 float-md-end mb-3 " width="300" height="300" >
              <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Cumque autem numquam deserunt.</p>
              <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Cumque autem numquam deserunt.</p>
              <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Cumque autem numquam deserunt.</p>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni sit magnam, earum quisquam dolorem maiores temporibus qui quod voluptatibus sint excepturi perspiciatis accusamus harum non, maxime nam velit, vitae omnis!</p>
            </div>
          </div>
        </div>
        <!-- tim -->
         <div class="container-fluid pt-5 pb-5 bg-light">
          <div class="container text-center">
            <h2 class="display-3" id="staff">Tim Kami</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae assumenda tempora necessitatibus delectus voluptas, quod error velit asperiores fugit perspiciatis?</p>
            <div class="row pt-4 gx-4 gy-4">
              <div class="col-md-4 text-center tim">
                <img src="img/kareem.jpg" class="rounded-circle mb-3" />
                <h4>Kareem</h4>
                <p>Programmer</p>
                <p>
                  <a href="" class="social"><i class="fa-brands fa-instagram"></i></a>
                  <a href="" class="social"><i class="fa-brands fa-square-facebook"></i></a>
                  <a href="" class="social"><i class="fa-brands fa-linkedin-in"></i></a>
                </p>
              </div>
              <div class="col-md-4 text-center tim">
                <img src="img/tom.jpg" class="rounded-circle mb-3" />
                <h4>Tom</h4>
                <p>Project Manager</p>
                <p>
                  <a href="" class="social"><i class="fa-brands fa-instagram"></i></a>
                  <a href="" class="social"><i class="fa-brands fa-square-facebook"></i></a>
                  <a href="" class="social"><i class="fa-brands fa-linkedin-in"></i></a>
                </p>
              </div>
              <div class="col-md-4 text-center tim">
                <img src="img/jenifer.jpg" class="rounded-circle mb-3" />
                <h4>Jenifer Angela</h4>
                <p>Graphic Designer</p>
                <p>
                  <a href="" class="social"><i class="fa-brands fa-instagram"></i></a>
                  <a href="" class="social"><i class="fa-brands fa-square-facebook"></i></a>
                  <a href="" class="social"><i class="fa-brands fa-linkedin-in"></i></a>
                </p>
              </div>
            </div>
          </div>
         </div>
         <!-- kontak -->
          <div class="container-fluid pt-5 pb-5 kontak">
            <div class="container">
              <h2 class="display-3 text-center" id="kontak">Kontak Kami</h2>
              <p class="text-center">Lorem ipsum dolor sit amet consectetur adipisicing elit. Possimus in voluptatum distinctio ad odit officia esse?</p>
              <div class="row pb-3">
                <div class="col-md-6">
                  <input class="form-control form-control-lg mb-3" type="text" placeholder="Nama" >
                  <input class="form-control form-control-lg mb-3" type="text" placeholder="Email">
                  <input class="form-control form-control-lg mb-3" type="text" placeholder="Handphone">
                </div>
                <div class="col-md-6">
                  <textarea class="form-control form-control-lg" rows="5"></textarea>
                </div>
              </div>
              <div class="col-md-3 mx-auto text-center">
                <button type="button" class="btn btn-danger bt-lg">Kirim Pesan</button>

              </div>
            </div>
          </div>
          <div class="container text-center pt-5 pb-5">
            All Rights Reserved &copy; 2024
          </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

    </body>
</html>