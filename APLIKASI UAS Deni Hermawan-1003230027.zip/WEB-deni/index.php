<?php include("config.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WEB DENI</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
</head>

<!-- NIM : 1003230027 -->
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Deni Hermawan</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="#beranda">Beranda</a></li>
                    <li class="nav-item"><a class="nav-link" href="#biodata">Biodata</a></li>
                    <li class="nav-item"><a class="nav-link" href="#pendidikan">Pendidikan</a></li>
                    <li class="nav-item"><a class="nav-link" href="#keahlian">Keahlian</a></li>
                    <li class="nav-item"><a class="nav-link" href="#pekerjaan">Pekerjaan</a></li>
                    <li class="nav-item"><a class="nav-link" href="#kontak">Kontak</a></li>
                    <li class="nav-item">
                    <a class="nav-link" href="dashboard.php"><button type="button" class="btn btn-danger btn-sm"> LOGIN </button></a>
                  </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Beranda -->
    <section id="beranda" class="text-center text-light" style="background: url('network.jpg') no-repeat center center/cover; height: 100vh;">
        <div class="container d-flex flex-column justify-content-center align-items-center h-100">
            <h1 class="display-4">"WELCOME TO DENI WEBSITE"</h1>
            <p class="lead">"The best way to predict the future is to create it."</p>
            <a href="#pendidikan" class="btn btn-primary btn-lg">Daftar Pendidikan</a>
        </div>
    </section>

    <!-- Biodata -->
    <section id="biodata" class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h3>Biodata</h3>
                    <ul class="list-group">
                        <li class="list-group-item">Nama: [Deni Hermawan]</li>
                        <li class="list-group-item">Tempat, Tanggal Lahir: [JAKARTA, 05-11-2003]</li>
                        <li class="list-group-item">Alamat: [KP.CIATER ll]</li>
                    </ul>
                </div>
                <div class="col-md-6 text-center">
                    <img src="images.jpg/orang sukses.jpg" alt="Foto Profil" class="img-fluid rounded-circle" style="max-width: 200px;">
                </div>
            </div>
        </div>
    </section>

    <!-- Pendidikan -->
    <section id="pendidikan" class="py-5 bg-light">
    <div class="container-fluid pendidikan pt-5 pb-5">
            <div class="container text-center">
                <h2 class="display-2" id="pendidikan">Pendidikan</h2>
                <div class="row pt-4">
                <?php
                    $no = 1;
                    $sql = "SELECT * FROM layanan";
                    $query = mysqli_query($db, $sql);

                    while($layanan = mysqli_fetch_array($query)){
                        echo "<div class='col-md-4'>";
                        echo "<span class='lingkaran'><i class='fas fa-fw fa-code fa-5x'></i></span>";
                        echo "<h3 class='mt-3'>".$layanan['nama']."</h3>";
                        echo "<p>".$layanan['deskripsi']."</p>";
                        echo "</div>";
                    }
                    ?>
                </div>
            </div>
        </div>
       
    </section>

   <!-- Keahlian -->
<section id="keahlian" class="py-5">
    <div class="container">
        <h2 class="text-center mb-4">Keahlian</h2>
        <div class="row text-center">
            <div class="col-md-6 mb-4">
                <div class="skill-card p-4 shadow-sm">
                        <i class="fas fa-code fa-3x text-primary mb-3"></i>
                    <h4>Programming</h4>
                    <p>Mahir dalam berbagai bahasa pemrograman seperti Python, JavaScript, dan C++.</p>
                </div>
            </div>
            <div class="col-md-6 mb-4">
                <div class="skill-card p-4 shadow-sm">
                    <i class="fas fa-paint-brush fa-3x text-primary mb-3"></i>
                    <h4>Seni & Desain</h4>
                    <p>Berpengalaman dalam desain grafis menggunakan Adobe Photoshop dan Figma.</p>
                </div>
            </div>
        </div>
    </div>
</section>

    <!-- Pekerjaan -->
    <section id="pekerjaan" class="py-5 bg-light">
        <div class="container">
            <h3 class="text-center mb-4">Pekerjaan</h3>
            <div class="row">
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Web Developer</h5>
                            <p class="card-text">seorang profesional yang bertanggung jawab untuk merancang, membuat, dan memelihara situs web atau aplikasi berbasis web. .</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Data Scientist</h5>
                            <p class="card-text"> seorang profesional yang bertanggung jawab untuk menganalisis, menginterpretasikan, dan mengekstrak wawasan dari data menggunakan metode ilmiah, algoritma, dan teknologi canggih. .</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Graphic Designer</h5>
                            <p class="card-text"> seorang profesional yang bertanggung jawab untuk menciptakan desain visual yang menarik dan komunikatif untuk menyampaikan pesan, ide, atau informasi tertentu..</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Freelance Developer</h5>
                            <p class="card-text">seorang pengembang perangkat lunak yang bekerja secara independen, tidak terikat dengan perusahaan tertentu sebagai karyawan tetap..</p>
                        </div>
                    </div>
                </div>
                <!-- Tambahkan card lainnya jika perlu -->
            </div>
        </div>
    </section>

    <!-- Kontak -->
    <section id="kontak" class="py-5">
        <div class="container">
            <h3 class="text-center mb-4">Kontak Kami</h3>
            <form>
                <div class="mb-3">
                    <label for="nama" class="form-label">Nama</label>
                    <input type="text" class="form-control" id="nama">
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email">
                </div>
                <div class="mb-3">
                    <label for="telp" class="form-label">Telepon</label>
                    <input type="text" class="form-control" id="telp">
                </div>
                <div class="mb-3">
                    <label for="pesan" class="form-label">Pesan</label>
                    <textarea class="form-control" id="pesan" rows="3"></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Kirim</button>
            </form>
        </div>
    </section>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

