<?php
include("config.php");
// cek apakah tombol simpan sudah diklik atau blum?
if(isset($_POST['simpan'])){
    // ambil data dari formulir
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $deskripsi = $_POST['deskripsi'];
    
    // buat query update
    $sql = "UPDATE layanan SET nama='$nama', deskripsi='$deskripsi' WHERE id=$id";
    $query = mysqli_query($db, $sql);

    // apakah query update berhasil?
    if( $query ) {
        // kalau berhasil alihkan ke halaman list-siswa.php
        header('Location: daftar-layanan.php?editStatus=sukses');
    } else {
        // kalau gagal tampilkan pesan
        header('Location: daftar-layanan.php?editStatus=gagal');
        //die("Gagal menyimpan perubahan...");
    }
} else {
    die("Akses dilarang...");
}
?>