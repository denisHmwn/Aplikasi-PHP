<?php

include("config.php");

// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['daftar'])){

    // ambil data dari formulir
    $nama = $_POST['nama'];
    $deskripsi = $_POST['deskripsi'];
    
    // buat query
    $sql = "INSERT INTO layanan (nama, deskripsi) VALUE ('$nama', '$deskripsi')";
    $query = mysqli_query($db, $sql);

    // apakah query simpan berhasil?
    if( $query ) {
        // kalau berhasil alihkan ke halaman index.php dengan status=sukses
        header('Location: daftar-layanan.php?addStatus=sukses');
    } else {
        // kalau gagal alihkan ke halaman indek.php dengan status=gagal
        header('Location: daftar-layanan.php?addStatus=gagal');
    }


} else {
    die("Akses dilarang...");
}

?>